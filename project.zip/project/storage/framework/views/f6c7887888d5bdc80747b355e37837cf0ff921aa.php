<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('mahasiswa.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" placeholder="nama" name="name">
    <input type="text" placeholder="class" name="class">  
    <input type="submit" value="Tambahkan">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/project/resources/views/create.blade.php ENDPATH**/ ?>