<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('mahasiswa.update', $m['no'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" placeholder="nama" name="old_name" value="<?php echo e($m['nama']); ?>">
        <input type="text" placeholder="nama" name="name" value="<?php echo e($m['nama']); ?>">
        <input type="text" placeholder="class" name="class" value="<?php echo e($m['class']); ?>">  
        <input type="submit" value="Tambahkan">
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/project/resources/views/edit.blade.php ENDPATH**/ ?>