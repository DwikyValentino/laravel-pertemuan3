<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>ID : <?php echo e($m['no']); ?></div>
    <div>Nama : <?php echo e($m['nama']); ?></div>
    <div>Kelas : <?php echo e($m['class']); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <a href="<?php echo e(route('mahasiswa.index')); ?>">< Kembali</a>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/project/resources/views/detail.blade.php ENDPATH**/ ?>