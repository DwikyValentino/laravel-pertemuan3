<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <h1 style="color: green"><?php echo e($message); ?></h1>
    <?php elseif($message = Session::get('error')): ?>
    <h1 style="color: red"><?php echo e($message); ?></h1>
    <?php endif; ?>
    <a href="<?php echo e(route('mahasiswa.create')); ?>">Tambah</a>
    <form action="" method="get">
    <select name="class">
        <option value="">Semua</option>
        <option value="6A">6A</option>
        <option value="6B">6B</option>
        <option value="6C">6C</option>
        <option value="6D">6D</option>
    </select>
    <input type="submit" value="Cari">
    </form>

    <table>
    <thead>
        <tr>
            <th><b>No.</b></th>
            <th><b>class</b></th>
            <th><b>Nama</b></th>
            <th><b>Action</b></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($m['no']); ?></td>
                <td><?php echo e($m['class']); ?></td>
                <td><?php echo e($m['nama']); ?></td>
                <td><a href="<?php echo e(route('mahasiswa.show', $m['no'])); ?>">Lihat</a> || <a href="<?php echo e(route('mahasiswa.edit',$m['no'])); ?>">Edit</a> <br>
                <form action="<?php echo e(route('mahasiswa.destroy', $m['no'])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="hidden" value="<?php echo e($m['nama']); ?>" name="name">
                    <input type="submit" value="Hapus" onclick="return alert('Apakah anda yakin?')">
                </form>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/project/resources/views/mahasiswa.blade.php ENDPATH**/ ?>